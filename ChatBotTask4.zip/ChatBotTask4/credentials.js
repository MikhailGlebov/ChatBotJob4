
// Datanautix help bot
//var accessToken = "b56ec2c85b2744ad81aeb6518d30a6ae";

    //----------------------- Emoji Bot ----------------------- //
    var credentialsAccessToken ="5ae7adf062fa4b5692087da997d2e3a5";

    //var bot name is used for the firebase database
    var credentialsBotName = "Emoji Bot";


    // // HighSchoolAna(Dev)
    // var credentialsAccessToken = "5489544adf6d490c8438cb7377f4bd60"

    // var credentialsBotName = "High School Ana (Dev)"


    var credentialsBaseUrl = "https://api.api.ai/v1/";

    // Initialize Firebase
    var credentialsConfig = {
        apiKey: "AIzaSyBV5PiUUxluc5ISR2hcItUH0T7HEH6_ENo",
        authDomain: "chatinterfacedb.firebaseapp.com",
        databaseURL: "https://chatinterfacedb.firebaseio.com",
        projectId: "chatinterfacedb",
        storageBucket: "chatinterfacedb.appspot.com",
        messagingSenderId: "922251038710"
    };